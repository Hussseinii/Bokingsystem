
package bokingsystem;

public class Bokingsystem {

    public static void main(String[] args) {
        
        
         //det var det jeg rakk , mangler en god del 
         System.out.println("Velkommen til BOKINGSYSTEM");
    }
    
}
