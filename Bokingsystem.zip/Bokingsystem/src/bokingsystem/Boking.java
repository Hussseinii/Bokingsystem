
package bokingsystem;

import java.util.Date;

public class Boking {
    
   private Rom rom;
   private int antall_personer;
   private Date dato;
 
   public  Boking(Rom rom , int antall_personer, Date dato)
    {
        this.rom = rom;
        this.antall_personer = antall_personer;
        this.dato = dato;
    }

    public Rom getRom() {
        return rom;
    }

    public int getAntall_personer() {
        return antall_personer;
    }

    public Date getDato() {
        return dato;
    }
    
}
